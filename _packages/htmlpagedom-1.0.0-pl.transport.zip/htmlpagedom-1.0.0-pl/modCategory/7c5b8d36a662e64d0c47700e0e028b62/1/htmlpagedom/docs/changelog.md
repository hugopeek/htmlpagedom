# Changelog for HtmlPageDom

## HtmlPageDom 1.0.0
Released on January 18, 2021

- Add documentation
- Exclude vendors folder from Git
- Update HtmlPageDom to v2.0 (BREAKING CHANGE)

Public release.

## HtmlPageDom 0.1.0
Released on October 4, 2018

Internal release, using HtmlPageDom v1.3.