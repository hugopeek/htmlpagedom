# Changelog for HtmlPageDom

## HtmlPageDom 1.1.1
Released on September 12, 2022

- Add constructor to base class

## HtmlPageDom 1.1.0
Released on July 18, 2022

- Autoload main class through extension package
- Auto-install library with local Composer

## HtmlPageDom 1.0.0
Released on January 18, 2021

- Add documentation
- Exclude vendor folder from Git
- Update HtmlPageDom to v2.0 (BREAKING CHANGE)

Public release.

## HtmlPageDom 0.1.0
Released on October 4, 2018

Internal release, using HtmlPageDom v1.3.