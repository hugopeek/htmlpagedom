<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '9efe50e82cc0a5c441871913facbcb5b',
      'native_key' => 'htmlpagedom',
      'filename' => 'modNamespace/cf6994361de1626b97d7bbe8adac6b0b.vehicle',
      'namespace' => 'htmlpagedom',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '1e77d359073a785a6973ee2beb9e7187',
      'native_key' => NULL,
      'filename' => 'modCategory/50f47477afb72612801621e3d2158e6e.vehicle',
      'namespace' => 'htmlpagedom',
    ),
  ),
);