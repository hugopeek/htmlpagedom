<?php
/**
 * @package htmlpagedom
 * @subpackage classfile
 */

require_once dirname(__DIR__, 2) . '/vendor/autoload.php';

/**
 * class HtmlPageDom
 */
class HtmlPageDom
{
}
