# Changelog for HtmlPageDom

## HtmlPageDom 1.2.0
Released on August 26, 2023

- Change license to MIT
- Update HtmlPageDom to v3.0 (requires PHP 8)

## HtmlPageDom 1.1.0
Released on July 18, 2022

- Autoload main class through extension package
- Auto-install library with local Composer

## HtmlPageDom 1.0.0
Released on January 18, 2021

- Add documentation
- Exclude vendor folder from Git
- Update HtmlPageDom to v2.0 (BREAKING CHANGE)

Public release.

## HtmlPageDom 0.1.0
Released on October 4, 2018

Internal release, using HtmlPageDom v1.3.