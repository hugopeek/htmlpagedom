<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'Copyright (c) 2018-2023 Hugo Peek

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is furnished
to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

The software is provided "as is", without warranty of any kind, express or
implied, including but not limited to the warranties of merchantability,
fitness for a particular purpose and noninfringement. In no event shall the
authors or copyright holders be liable for any claim, damages or other
liability, whether in an action of contract, tort or otherwise, arising from,
out of or in connection with the software or the use or other dealings in
the software.',
    'readme' => '# HtmlPageDom

A MODX wrapper for HtmlPageDom, a library for easy DOM manipulation of HTML documents.

For more info, visit https://github.com/wasinger/htmlpagedom.

## Plugin usage

The included plugin is just a primer for getting started (it\'s also disabled).

To start using it, copy and rename the plugin and attach it to the OnWebPagePrerender event.

## Examples

Add classes to elements:
```php
$dom->filter(\'h1:not(.header)\')->addClass(\'ui header\');
$dom->filter(\'h2:not(.header)\')->addClass(\'ui header\');
```

Add class to body based on ClientConfig setting:
```php
if ($modx->getObject(\'cgSetting\', array(\'key\' => \'theme_page_background_color\'))->get(\'value\') !== \'ffffff\') {
    $dom->filter(\'body\')->addClass(\'non-white\');
}
```

Apply your own function to each filtered node:
```php
$dom->filter(\'.inverted.segment\')
    ->each(function (HtmlPageCrawler $segment) {

        // Prevent elements from having the same color as their parent background
        if ($segment->hasClass(\'primary-color\')) {
            $segment
                ->filter(\'.primary.button\')
                ->removeClass(\'basic\')
                ->addClass(\'inverted\')
            ;
        }
    })
;
```

Move elements out of their parent container:
```php
$dom->filter(\'.swiper-container\')
    ->parents()
    ->each(function (HtmlPageCrawler $parent) {
        if ($parent->hasClass(\'nested\',\'slider\')) {
            $parent->filter(\'.swiper-button-prev\')->appendTo($parent);
            $parent->filter(\'.swiper-button-next\')->appendTo($parent);
        }
    })
;
```

For more examples, see the [ManipulateDOM plugin](https://github.com/hugopeek/romanesco-patterns/blob/master/core/components/romanesco/elements/plugins/07_computations/c_content/manipulatedom.plugin.php) in Romanesco.

## Why

A page crawler to manipulate the DOM... Yes, that is exactly what jQuery does! But now we can do it server side, before the page is rendered. Much faster and more reliable.

Have fun!

## References

Some interesting resources:

- https://symfony.com/doc/current/components/dom_crawler.html
- https://victor.4devs.io/en/web-scraping/parsing-content-with-dom-crawler-and-css-selector.html
- https://stackoverflow.com/questions/19177578/symfony2-domcrawler-remove-nodes-from-domelement#29401018
',
    'changelog' => '# Changelog for HtmlPageDom

## HtmlPageDom 1.2.0
Released on August 26, 2023

- Change license to MIT
- Update HtmlPageDom to v3.0 (requires PHP 8)

## HtmlPageDom 1.1.0
Released on July 18, 2022

- Autoload main class through extension package
- Auto-install library with local Composer

## HtmlPageDom 1.0.0
Released on January 18, 2021

- Add documentation
- Exclude vendor folder from Git
- Update HtmlPageDom to v2.0 (BREAKING CHANGE)

Public release.

## HtmlPageDom 0.1.0
Released on October 4, 2018

Internal release, using HtmlPageDom v1.3.',
    'requires' => 
    array (
      'modx' => '>=2.4',
      'php' => '>=8.0',
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'd7082e2f993d68a122e363e4ddb1edb2',
      'native_key' => 'htmlpagedom',
      'filename' => 'modNamespace/fd29cff3d7cc7ef9041c06b9cfd22566.vehicle',
      'namespace' => 'htmlpagedom',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'ebc8e8264b246785b463844ab2c5a885',
      'native_key' => NULL,
      'filename' => 'modCategory/06e360e505d4362d6766d85eb6a00ad5.vehicle',
      'namespace' => 'htmlpagedom',
    ),
  ),
);